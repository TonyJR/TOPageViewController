//
//  ExampleViewController.h
//  TOPageView
//
//  Created by Tony on 17/6/23.
//  Copyright © 2017年 Tony. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExampleViewController : UIViewController

- (instancetype)initWithTitle:(NSString *)title;

@end
